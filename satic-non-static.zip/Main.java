class Program
{
    static int x,y; //static variables
    static {   //static block
      System.out.println("static block");
      x=10;
      y=20;
    }
    static void display1()
    {                         //static method 
    System.out.println("Static method");
    System.out.println(x);
    System.out.println(y);
    }
int a,b;  //non static variables
{
    System.out.println("Non static block"); //non static block
    a=111;
    b=222;
    x=333;
    y=444;
}
void display2()
{   //non static method
    System.out.println("Non static method");
    System.out.println(a);
    System.out.println(b);
    System.out.println(x);
    System.out.println(y);
}
}
class Main
{
	public static void main(String[] args) 
	{
		Program.display1(); //calling static method 
		Program p = new Program(); //object creaiton for non statid elements
		p.display2(); //calling non static method by reference variable or object
	}
}
